package com.nanodegree.google_developers.hammad.progress_app.model;

import com.nanodegree.google_developers.hammad.progress_app.BuildConfig;

/**
 * Created by Guest on 7/19/16.
 */
public class Constants {
    public static final String FIREBASE_CHILD_TASK = "tasks";

}
