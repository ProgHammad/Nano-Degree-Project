package com.nanodegree.google_developers.hammad.progress_app.adapters;//package com.epicodus.progresstracker.adapters;
//
//import android.content.Context;
//import android.support.v7.widget.RecyclerView;
//import android.view.View;
//
//import com.epicodus.progresstracker.model.Task;
//
///**
// * Created by Guest on 7/19/16.
// */
//public class FirebseRestaurantViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
//    View mView;
//    Context mContext;
//
//    public FirebaseTaskViewHolder(View itemView) {
//        super(itemView);
//        mView = itemView;
//        mContext = itemView.getContext();
//        itemView.setOnClickListener(this);
//    }
//
//    public void bindTask(Task task) {
//
//    }
//
//}
